import UIKit


public func solution(_ A :[Int]) -> Int {
   //TODO: START IMPLEMENT HERE
    return 0
}

print(solution([10,50,5,1])) //MARK: Test Cases

